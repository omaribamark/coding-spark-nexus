const get_started = require('../assets/images/getstarted.png');
const splash1 = require('../assets/images/spash_1.png');
// Using splash1 as fallback for splash2 and splash3
const splash2 = splash1;
const splash3 = splash1;

export default {
  get_started,
  splash1,
  splash2,
  splash3,
};
