import images from "./images";
import icons from "./icons";



export {
    images,
    icons
}