import HomeTab from './HomeTab';
import ClaimsListTab from './ClaimsListTab';
import SettingTab from './SettingTab';
import AITab from './AITab';

export {HomeTab, ClaimsListTab, SettingTab, AITab};
