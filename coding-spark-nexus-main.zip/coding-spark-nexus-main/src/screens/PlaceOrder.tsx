import {View, Text} from 'react-native';
import React from 'react';

type Props = {};

const PlaceOrder = (props: Props) => {
  return (
    <View>
      <Text>PlaceOrder</Text>
    </View>
  );
};

export default PlaceOrder;
